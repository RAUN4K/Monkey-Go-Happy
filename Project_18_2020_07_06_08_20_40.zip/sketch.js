var backdrop,jungle;

var bananaImg, obstacleImg;

var ground;
//ground.velocityX = -2

var monkey,monkeyWalk;

//var monkey1,monkey2,monkey3,monkey4,monkey5,monkey6,monkey7,monkey8,monkey9,monkey10;

var stones,bananas;

var ObstaclesGroup, BananasGroup;

var score = 0;



function preload(){
  
  jungle = loadImage("jungle.jpg");
  
  ground = loadImage("ground.jpg");

monkeyWalk = loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
  stones = loadImage("stone.png");
  bananas = loadImage("Banana.png");
}



function setup(){
  createCanvas(600, 400);
  
  monkey = createSprite(50,250);
  monkey.addAnimation("monkey_01.png",monkeyWalk);
  monkey.scale = 0.125;
  
  backdrop.addImage(jungle);
  
  ground = createSprite(600,300,1200,20);
  
  ObstaclesGroup = new Group();
  BananasGroup = new Group();
}



function draw() {
  background(220);
  ground.visible = false;
  
  stroke("white");
  textSize(20);
  text("Score: "+ score,250,40);

  
    /*switch (score){
    case 10: monkey.scale = 0.15;
              break;
    case 20: monkey.scale = 0.175;
              break;
    case 30: monkey.scale = 0.2;
              break;
    case 40: monkey.scale = 0.225;
              break;
    case 50: monkey.scale = 0.25;
              break;
  }*/
  
  if(ObstaclesGroup.isTouching(monkey)){
    score = score - 1
    monkey.scale = 0.1;
  }
  
  if(monkey.isTouching(BananasGroup)){
  score = score + 2
  BananasGroup.destroyEach();
  }
  
  if(score > 10){
    monkey.scale = monkey.scale + 0.125;
  }

  if(keyDown("space")){
    monkey.velocityY = -10;
  }

monkey.velocityY = monkey.velocityY + 0.8;
  
createBananas();
createObstacles();

monkey.collide(ground);

drawSprites();
}



function createBananas(){
  
if(frameCount % 150 === 0){
  var banana = createSprite(600,150,20,20);
  var rand_number = random(60,200);
  
  banana.addImage(bananas);
  banana.velocityX = -4;
  banana.scale = 0.05;
  banana.y = (rand_number);
  
  banana.lifetime = 400;
  
  BananasGroup.add(banana);
}

}



function createObstacles(){
  
if(World.frameCount % 300 === 0){
  var rocks = createSprite(600,275,20,20);
  
  rocks.addImage(stones);
  rocks.velocityX = -2;
  rocks.scale = 0.25;
  
  rocks.lifetime = 400;
  
  ObstaclesGroup.add(rocks);
}

}